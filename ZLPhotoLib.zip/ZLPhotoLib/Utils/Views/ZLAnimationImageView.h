//
//  ZLAnimationImageView.h
//  ZLAssetsPickerDemo
//
//  Created by 张磊 on 14-11-27.
//  Copyright (c) 2014年 com.zixue101.www. All rights reserved.
//

#import "ZLAnimationBaseView.h"

// 传图片数组
static NSString *const UIViewAnimationImages = @"UIViewAnimationImages";
// 图片的缩小时候的模式
static NSString *const UIViewAnimationZoomMinScaleImageViewContentModel = @"UIViewAnimationZoomMinScaleImageViewContentModel";

@interface ZLAnimationImageView : ZLAnimationBaseView

@end
