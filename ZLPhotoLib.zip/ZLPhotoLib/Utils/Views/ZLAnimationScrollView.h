//
//  ZLAnimationScrollView.h
//  ZLAssetsPickerDemo
//
//  Created by 张磊 on 14-11-28.
//  Copyright (c) 2014年 com.zixue101.www. All rights reserved.
//

#import "ZLAnimationImageView.h"

@interface ZLAnimationScrollView : ZLAnimationImageView


@end
