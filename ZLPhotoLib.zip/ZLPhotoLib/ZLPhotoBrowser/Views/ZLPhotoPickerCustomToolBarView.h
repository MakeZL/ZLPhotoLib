//
//  ZLPhotoPickerCustomToolBarView.h
//  ZLAssetsPickerDemo
//
//  Created by 张磊 on 15-1-26.
//  Copyright (c) 2015年 com.zixue101.www. All rights reserved.
//

/**
 *  Note: 图片游览器自定义View
 *  在里面创建的控件会添加到 ZLPhotoPickerBrowserViewController view里面
 */
#import <UIKit/UIKit.h>

@interface ZLPhotoPickerCustomToolBarView : UIView

@end
